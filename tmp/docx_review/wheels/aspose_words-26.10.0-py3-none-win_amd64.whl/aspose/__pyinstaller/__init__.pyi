"""Pyinstaller hook folder"""
