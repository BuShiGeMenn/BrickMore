"""Pyinstaller hook folder"""
