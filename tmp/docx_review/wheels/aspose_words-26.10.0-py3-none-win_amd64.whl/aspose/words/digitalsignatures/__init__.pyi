﻿import aspose.words
import aspose.pydrawing
import datetime
import decimal
import io
import uuid
from typing import Iterable, List
from enum import Enum

class CertificateHolder:
    """Represents a holder of **X509Certificate2** instance.
    To learn more, visit the `Work with Digital Signatures <https://docs.aspose.com/words/python-net/working-with-digital-signatures/>` documentation article.
    
    :class:`CertificateHolder` can be created by static factory methods only.
    It contains an instance of **X509Certificate2** which is used to introduce private, public keys and certificate chains into the system.
    This class is applied in :class:`DigitalSignatureUtil` and :class:`aspose.words.saving.PdfDigitalSignatureDetails` instead of obsolete methods with
    System.Security.Cryptography.X509Certificates.X509Certificate2 as parameters."""
    
    @overload
    @staticmethod
    def create(cert_bytes: bytes, password: str) -> aspose.words.digitalsignatures.CertificateHolder:
        """Creates :class:`CertificateHolder` object using byte array of PKCS12 store and its password.
        
        :param cert_bytes: A byte array that contains data from an X.509 certificate.
        :param password: The password required to access the X.509 certificate data.
        :returns: An instance of :class:`CertificateHolder`
        
        :raises RuntimeError (Proxy error(InvalidParameterException)): Thrown if *certBytes* is``None``
        :raises RuntimeError (Proxy error(InvalidParameterException)): Thrown if *password* is``None``
        :raises RuntimeError (Proxy error(SecurityException)): Thrown if PKCS12 store contains no aliases
        :raises RuntimeError (Proxy error(IOException)): Thrown if there is wrong password or corrupted file."""
        ...
    
    @overload
    @staticmethod
    def create(file_name: str, password: str) -> aspose.words.digitalsignatures.CertificateHolder:
        """Creates :class:`CertificateHolder` object using path to PKCS12 store and its password.
        
        :param file_name: The name of a certificate file.
        :param password: The password required to access the X.509 certificate data.
        :returns: An instance of :class:`CertificateHolder`
        
        :raises RuntimeError (Proxy error(InvalidParameterException)): Thrown if *fileName* is``None``
        :raises RuntimeError (Proxy error(InvalidParameterException)): Thrown if *password* is``None``
        :raises RuntimeError (Proxy error(SecurityException)): Thrown if PKCS12 store contains no aliases
        :raises RuntimeError (Proxy error(IOException)): Thrown if there is wrong password or corrupted file."""
        ...
    
    @overload
    @staticmethod
    def create(file_name: str, password: str, alias: str) -> aspose.words.digitalsignatures.CertificateHolder:
        """Creates :class:`CertificateHolder` object using path to PKCS12 store, its password and the alias by using which private key and certificate will be found.
        
        :param file_name: The name of a certificate file.
        :param password: The password required to access the X.509 certificate data.
        :param alias: The associated alias for a certificate and its private key
        :returns: An instance of :class:`CertificateHolder`
        
        :raises RuntimeError (Proxy error(InvalidParameterException)): Thrown if *fileName* is``None``
        :raises RuntimeError (Proxy error(InvalidParameterException)): Thrown if *password* is``None``
        :raises RuntimeError (Proxy error(SecurityException)): Thrown if PKCS12 store contains no aliases
        :raises RuntimeError (Proxy error(IOException)): Thrown if there is wrong password or corrupted file.
        :raises RuntimeError (Proxy error(SecurityException)): Thrown if there is no private key with the given alias"""
        ...
    
    @property
    def certificate(self) -> None:
        """Returns the instance of **X509Certificate2** which holds private, public keys and certificate chain.
        
        :returns: System.Security.Cryptography.X509Certificates.X509Certificate2 instance"""
        ...
    
    ...

class DigitalSignature:
    """Represents a digital signature on a document and the result of its verification.
    To learn more, visit the `Work with Digital Signatures <https://docs.aspose.com/words/python-net/working-with-digital-signatures/>` documentation article."""
    
    @property
    def signature_type(self) -> aspose.words.digitalsignatures.DigitalSignatureType:
        """Gets the type of the digital signature."""
        ...
    
    @property
    def sign_time(self) -> datetime.datetime:
        """Gets the time the document was signed."""
        ...
    
    @property
    def comments(self) -> str:
        """Gets the signing purpose comment."""
        ...
    
    @property
    def windows_version(self) -> str:
        """Gets the Windows version for the digital signature."""
        ...
    
    @property
    def application_version(self) -> str:
        """Gets the application version for the digital signature."""
        ...
    
    @property
    def office_version(self) -> str:
        """Gets the Office version for the digital signature."""
        ...
    
    @property
    def horizontal_resolution(self) -> int:
        """Gets the horizontal resolution for the digital signature."""
        ...
    
    @property
    def vertical_resolution(self) -> int:
        """Gets the vertical resolution for the digital signature."""
        ...
    
    @property
    def color_depth(self) -> int:
        """Gets the color depth for the digital signature."""
        ...
    
    @property
    def subject_name(self) -> str:
        """Returns the subject distinguished name of the certificate that was used to sign the document."""
        ...
    
    @property
    def issuer_name(self) -> str:
        """Returns the subject distinguished name of the certificate isuuer."""
        ...
    
    @property
    def is_valid(self) -> bool:
        """Returns ``True`` if this digital signature is valid and the document has not been tampered with."""
        ...
    
    @property
    def certificate_holder(self) -> aspose.words.digitalsignatures.CertificateHolder:
        """Returns the certificate holder object that contains the certificate was used to sign the document."""
        ...
    
    @property
    def signature_value(self) -> bytes:
        """Gets an array of bytes representing a signature value."""
        ...
    
    ...

class DigitalSignatureCollection:
    """Provides a read-only collection of digital signatures attached to a document.
    To learn more, visit the `Work with Digital Signatures <https://docs.aspose.com/words/python-net/working-with-digital-signatures/>` documentation article.
    
    :attr:`aspose.words.Document.digital_signatures`"""
    
    def __init__(self):
        ...
    
    def __getitem__(self, index: int) -> aspose.words.digitalsignatures.DigitalSignature:
        """Gets a document signature at the specified index.
        
        :param index: Zero-based index of the signature."""
        ...
    
    @property
    def is_valid(self) -> bool:
        """Returns ``True`` if all digital signatures in this collection are valid and the document has not been tampered with
        Also returns ``True`` if there are no digital signatures.
        Returns ``False`` if at least one digital signature is invalid."""
        ...
    
    @property
    def count(self) -> int:
        """Gets the number of elements contained in the collection."""
        ...
    
    ...

class DigitalSignatureTimestampSettings:
    """Contains settings of the digital signature timestamp."""
    
    @overload
    def __init__(self):
        """Initializes a new instance of :class:`DigitalSignatureTimestampSettings` class."""
        ...
    
    @overload
    def __init__(self, server_url: str, user_name: str, password: str):
        """Initializes a new instance of :class:`DigitalSignatureTimestampSettings` class.
        
        :param server_url: Timestamp server URL.
        :param user_name: Timestamp server user name.
        :param password: Timestamp server password."""
        ...
    
    @overload
    def __init__(self, server_url: str, user_name: str, password: str, timeout: datetime.timespan):
        """Initializes a new instance of :class:`DigitalSignatureTimestampSettings` class.
        
        :param server_url: Timestamp server URL.
        :param user_name: Timestamp server user name.
        :param password: Timestamp server password.
        :param timeout: Time-out value for accessing timestamp server."""
        ...
    
    @property
    def server_url(self) -> str:
        """Gets or sets a string value representing timestamp server URL.
        The default value is ``None``.
        
        If ``None``, then the digital signature will not be time-stamped."""
        ...
    
    @server_url.setter
    def server_url(self, value: str):
        ...
    
    @property
    def user_name(self) -> str:
        """Gets or sets a string value representing timestamp server user name.
        The default value is ``None``."""
        ...
    
    @user_name.setter
    def user_name(self, value: str):
        ...
    
    @property
    def password(self) -> str:
        """Gets or sets a string value representing timestamp server password.
        The default value is ``None``."""
        ...
    
    @password.setter
    def password(self, value: str):
        ...
    
    @property
    def timeout(self) -> datetime.timespan:
        """Gets or sets a time-out value for accessing timestamp server.
        The default value is 100 seconds."""
        ...
    
    @timeout.setter
    def timeout(self, value: datetime.timespan):
        ...
    
    ...

class DigitalSignatureUtil:
    """Provides methods for signing document.
    To learn more, visit the `Work with Digital Signatures <https://docs.aspose.com/words/python-net/working-with-digital-signatures/>` documentation article.
    
    Since digital signature works with file content rather than Document Object Model these methods are put into a separate class.
    
    Supported formats are:
    :attr:`aspose.words.LoadFormat.DOC`,
    :attr:`aspose.words.LoadFormat.DOT`,
    :attr:`aspose.words.LoadFormat.DOCX`,
    :attr:`aspose.words.LoadFormat.DOTX`,
    :attr:`aspose.words.LoadFormat.DOCM`,
    :attr:`aspose.words.LoadFormat.DOTM`,
    :attr:`aspose.words.LoadFormat.ODT`,
    :attr:`aspose.words.LoadFormat.OTT`."""
    
    @overload
    @staticmethod
    def sign(src_stream: io.BytesIO, dst_stream: io.BytesIO, cert_holder: aspose.words.digitalsignatures.CertificateHolder, sign_options: aspose.words.digitalsignatures.SignOptions) -> None:
        """Signs source document using given :class:`CertificateHolder` and :class:`SignOptions`
        with digital signature and writes signed document to destination stream.
        Supported formats are:
        :attr:`aspose.words.LoadFormat.DOC`,
        :attr:`aspose.words.LoadFormat.DOT`,
        :attr:`aspose.words.LoadFormat.DOCX`,
        :attr:`aspose.words.LoadFormat.DOTX`,
        :attr:`aspose.words.LoadFormat.DOCM`,
        :attr:`aspose.words.LoadFormat.DOTM`,
        :attr:`aspose.words.LoadFormat.ODT`,
        :attr:`aspose.words.LoadFormat.OTT`.
        
        **Output will be written to the start of stream and stream size will be updated with content length.**
        
        :param src_stream: The stream which contains the document to sign.
        :param dst_stream: The stream that signed document will be written to.
        :param cert_holder: :class:`CertificateHolder` object with certificate that used to sign file.
                            The certificate in holder MUST contain private keys and have the X509KeyStorageFlags.Exportable flag set.
        :param sign_options: :class:`SignOptions` object with various signing options."""
        ...
    
    @overload
    @staticmethod
    def sign(src_file_name: str, dst_file_name: str, cert_holder: aspose.words.digitalsignatures.CertificateHolder, sign_options: aspose.words.digitalsignatures.SignOptions) -> None:
        """Signs source document using given :class:`CertificateHolder` and :class:`SignOptions`
        with digital signature and writes signed document to destination file.
        Supported formats are:
        :attr:`aspose.words.LoadFormat.DOC`,
        :attr:`aspose.words.LoadFormat.DOT`,
        :attr:`aspose.words.LoadFormat.DOCX`,
        :attr:`aspose.words.LoadFormat.DOTX`,
        :attr:`aspose.words.LoadFormat.DOCM`,
        :attr:`aspose.words.LoadFormat.DOTM`,
        :attr:`aspose.words.LoadFormat.ODT`,
        :attr:`aspose.words.LoadFormat.OTT`.
        
        :param src_file_name: The file name of the document to sign.
        :param dst_file_name: The file name of the signed document output.
        :param cert_holder: :class:`CertificateHolder` object with certificate that used to sign file.
                            The certificate in holder MUST contain private keys and have the X509KeyStorageFlags.Exportable flag set.
        :param sign_options: :class:`SignOptions` object with various signing options."""
        ...
    
    @overload
    @staticmethod
    def sign(src_stream: io.BytesIO, dst_stream: io.BytesIO, cert_holder: aspose.words.digitalsignatures.CertificateHolder) -> None:
        """Signs source document using given :class:`CertificateHolder` with digital signature
        and writes signed document to destination stream.
        Supported formats are:
        :attr:`aspose.words.LoadFormat.DOC`,
        :attr:`aspose.words.LoadFormat.DOT`,
        :attr:`aspose.words.LoadFormat.DOCX`,
        :attr:`aspose.words.LoadFormat.DOTX`,
        :attr:`aspose.words.LoadFormat.DOCM`,
        :attr:`aspose.words.LoadFormat.DOTM`,
        :attr:`aspose.words.LoadFormat.ODT`,
        :attr:`aspose.words.LoadFormat.OTT`.
        
        **Output will be written to the start of stream and stream size will be updated with content length.**
        
        :param src_stream: The stream which contains the document to sign.
        :param dst_stream: The stream that signed document will be written to.
        :param cert_holder: :class:`CertificateHolder` object with certificate that used to sign file.
                            The certificate in holder MUST contain private keys and have the X509KeyStorageFlags.Exportable flag set."""
        ...
    
    @overload
    @staticmethod
    def sign(src_file_name: str, dst_file_name: str, cert_holder: aspose.words.digitalsignatures.CertificateHolder) -> None:
        """Signs source document using given :class:`CertificateHolder` with digital signature
        and writes signed document to destination file.
        Supported formats are:
        :attr:`aspose.words.LoadFormat.DOC`,
        :attr:`aspose.words.LoadFormat.DOT`,
        :attr:`aspose.words.LoadFormat.DOCX`,
        :attr:`aspose.words.LoadFormat.DOTX`,
        :attr:`aspose.words.LoadFormat.DOCM`,
        :attr:`aspose.words.LoadFormat.DOTM`,
        :attr:`aspose.words.LoadFormat.ODT`,
        :attr:`aspose.words.LoadFormat.OTT`.
        
        :param src_file_name: The file name of the document to sign.
        :param dst_file_name: The file name of the signed document output.
        :param cert_holder: :class:`CertificateHolder` object with certificate that used to sign file.
                            The certificate in holder MUST contain private keys and have the X509KeyStorageFlags.Exportable flag set."""
        ...
    
    @overload
    @staticmethod
    def remove_all_signatures(src_file_name: str, dst_file_name: str) -> None:
        """Removes all digital signatures from source file and writes unsigned file to destination file.
        The following formats are compatible for digital signature removal:
        :attr:`aspose.words.LoadFormat.DOC`,
        :attr:`aspose.words.LoadFormat.DOT`,
        :attr:`aspose.words.LoadFormat.DOCX`,
        :attr:`aspose.words.LoadFormat.DOTX`,
        :attr:`aspose.words.LoadFormat.DOCM`,
        :attr:`aspose.words.LoadFormat.DOTM`,
        :attr:`aspose.words.LoadFormat.ODT`,
        :attr:`aspose.words.LoadFormat.OTT`."""
        ...
    
    @overload
    @staticmethod
    def remove_all_signatures(src_stream: io.BytesIO, dst_stream: io.BytesIO) -> None:
        """Removes all digital signatures from document in source stream and writes unsigned document to destination stream.
        **Output will be written to the start of stream and stream size will be updated with content length.**
        
        The following formats are compatible for digital signature removal:
        :attr:`aspose.words.LoadFormat.DOC`,
        :attr:`aspose.words.LoadFormat.DOT`,
        :attr:`aspose.words.LoadFormat.DOCX`,
        :attr:`aspose.words.LoadFormat.DOTX`,
        :attr:`aspose.words.LoadFormat.DOCM`,
        :attr:`aspose.words.LoadFormat.DOTM`,
        :attr:`aspose.words.LoadFormat.ODT`,
        :attr:`aspose.words.LoadFormat.OTT`."""
        ...
    
    @overload
    @staticmethod
    def load_signatures(file_name: str) -> aspose.words.digitalsignatures.DigitalSignatureCollection:
        """Loads digital signatures from document.
        
        :param file_name: Path to the document.
        :returns: Collection of digital signatures. Returns empty collection if file is not signed."""
        ...
    
    @overload
    @staticmethod
    def load_signatures(stream: io.BytesIO) -> aspose.words.digitalsignatures.DigitalSignatureCollection:
        """Loads digital signatures from document using stream.
        
        :param stream: Stream with the document.
        :returns: Collection of digital signatures. Returns empty collection if file is not signed."""
        ...
    
    ...

class SignOptions:
    """Allows to specify options for document signing.
    To learn more, visit the `Work with Digital Signatures <https://docs.aspose.com/words/python-net/working-with-digital-signatures/>` documentation article."""
    
    def __init__(self):
        ...
    
    @property
    def comments(self) -> str:
        """Specifies comments on the digital signature.
        Default value is **empty string**()."""
        ...
    
    @comments.setter
    def comments(self, value: str):
        ...
    
    @property
    def sign_time(self) -> datetime.datetime:
        """The date of signing.
        Default value is **current time** (datetime.datetime.now)"""
        ...
    
    @sign_time.setter
    def sign_time(self, value: datetime.datetime):
        ...
    
    @property
    def signature_line_id(self) -> uuid.UUID:
        """Signature line identifier.
        Default value is **Empty (all zeroes) Guid**.
        
        When set, it associates :class:`aspose.words.drawing.SignatureLine` with corresponding :class:`DigitalSignature`."""
        ...
    
    @signature_line_id.setter
    def signature_line_id(self, value: uuid.UUID):
        ...
    
    @property
    def signature_line_image(self) -> bytes:
        """The image that will be shown in associated :class:`aspose.words.drawing.SignatureLine`.
        Default value is ``None``."""
        ...
    
    @signature_line_image.setter
    def signature_line_image(self, value: bytes):
        ...
    
    @property
    def decryption_password(self) -> str:
        """The password to decrypt source document.
        Default value is **empty string** ().
        
        If OOXML document is encrypted, you should provide decryption password
        to decrypt source document before it will be signed.
        This is not required for documents in binary DOC format."""
        ...
    
    @decryption_password.setter
    def decryption_password(self, value: str):
        ...
    
    @property
    def provider_id(self) -> uuid.UUID:
        """Specifies the class ID of the signature provider.
        Default value is **Empty (all zeroes) Guid**.
        
        The cryptographic service provider (CSP) is an independent software module that actually performs
        cryptography algorithms for authentication, encoding, and encryption. MS Office reserves the value
        of {00000000-0000-0000-0000-000000000000} for its default signature provider.
        
        The GUID of the additionally installed provider should be obtained from the documentation shipped with the provider.
        
        In addition, all the installed cryptographic providers are enumerated in windows registry.
        It can be found in the following path: HKLM\\SOFTWARE\\Microsoft\\Cryptography\\Defaults\\Provider.
        There is a key name "CP Service UUID" which corresponds to a GUID of signature provider."""
        ...
    
    @provider_id.setter
    def provider_id(self, value: uuid.UUID):
        ...
    
    @property
    def windows_version(self) -> str:
        """Gets or sets the Windows version for the digital signature.
        Default value is "6.1"."""
        ...
    
    @windows_version.setter
    def windows_version(self, value: str):
        ...
    
    @property
    def application_version(self) -> str:
        """Gets or sets the application version for the digital signature.
        Default value is "12.0"."""
        ...
    
    @application_version.setter
    def application_version(self, value: str):
        ...
    
    @property
    def office_version(self) -> str:
        """Gets or sets the Office version for the digital signature.
        Default value is "12.0"."""
        ...
    
    @office_version.setter
    def office_version(self, value: str):
        ...
    
    @property
    def horizontal_resolution(self) -> int:
        """Gets or sets the horizontal resolution for the digital signature.
        Default value is 1920."""
        ...
    
    @horizontal_resolution.setter
    def horizontal_resolution(self, value: int):
        ...
    
    @property
    def vertical_resolution(self) -> int:
        """Gets or sets the vertical resolution for the digital signature.
        Default value is 1200."""
        ...
    
    @vertical_resolution.setter
    def vertical_resolution(self, value: int):
        ...
    
    @property
    def color_depth(self) -> int:
        """Gets or sets the color depth for the digital signature.
        Default value is 32."""
        ...
    
    @color_depth.setter
    def color_depth(self, value: int):
        ...
    
    @property
    def xml_dsig_level(self) -> aspose.words.digitalsignatures.XmlDsigLevel:
        """Specifies the level of a digital signature based on the XML-DSig standard.
        The default value is :attr:`XmlDsigLevel.XML_D_SIG`.
        
        Different levels of XAdES signatures can be created starting with Office 2010.
        
        This is only relevant for the following document formats: DOC, DOCX, and XPS.
        It is ignored in other document formats, which always produce a plain XML-DSig signature regardless of this setting."""
        ...
    
    @xml_dsig_level.setter
    def xml_dsig_level(self, value: aspose.words.digitalsignatures.XmlDsigLevel):
        ...
    
    @property
    def timestamp_settings(self) -> aspose.words.digitalsignatures.DigitalSignatureTimestampSettings:
        """Specifies settings for timestamping the digital signature using an RFC 3161 timestamp authority (TSA).
        The default value is ``None`` and the digital signature will not be time-stamped.
        
        When this property is set to a valid :class:`DigitalSignatureTimestampSettings` object,
        and :attr:`SignOptions.xml_dsig_level` is set to :attr:`XmlDsigLevel.X_AD_ES_T` or higher,
        the digital signature will be time-stamped."""
        ...
    
    @timestamp_settings.setter
    def timestamp_settings(self, value: aspose.words.digitalsignatures.DigitalSignatureTimestampSettings):
        ...
    
    ...

class DigitalSignatureType(Enum):
    """Specifies the type of a digital signature."""
    
    """Indicates an error, unknown digital signature type."""
    UNKNOWN: int
    
    """The Crypto API signature method used in Microsoft Word 97-2003 .DOC binary documents."""
    CRYPTO_API: int
    
    """The XmlDsig signature method used in OOXML and OpenDocument documents."""
    XML_DSIG: int
    

class XmlDsigLevel(Enum):
    """Specifies the level of a digital signature based on XML-DSig standard."""
    
    """Specifies XML-DSig signature level.
    
    A simple digital signature that should not be trusted after its signing certificate expires."""
    XML_D_SIG: int
    
    """Specifies XAdES-EPES signature level.
    
    Adds information about the signing certificate to the XML-DSig signature.
    A malicious user cannot switch the signing certificate for another certificate with the same public/private key."""
    X_AD_ES_EPES: int
    
    """Specifies XAdES-T signature level.
    
    Adds an RFC 3161 timestamp of the signature value to the XAdES-EPES signature, obtained from a
    trusted timestamp authority (TSA). This proves the signature existed at a specific point in time,
    independent of the signing certificate's validity period."""
    X_AD_ES_T: int
    

