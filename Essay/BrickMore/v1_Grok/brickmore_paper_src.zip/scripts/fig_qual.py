import os, json, re, glob, sys
sys.path.insert(0, os.path.dirname(__file__))
from isorender import render
from PIL import Image
SRC='/workspace/brickmore/src/BrickNet_BrickGPT_Compirasion'
OUT='/workspace/brickmore/paper/figures/qual'; os.makedirs(OUT,exist_ok=True)
def find_dir(name):
    for r,ds,fs in os.walk(SRC):
        if os.path.basename(r)==name: return r
def find_file(part, pid):
    for r,ds,fs in os.walk(SRC):
        if r.endswith(os.path.join('ab_experiment_20261109',part,pid)) and 'bricks.txt' in fs: return os.path.join(r,'bricks.txt')
PAL=[(31,78,140),(214,92,50),(60,150,80),(200,160,40),(140,70,160),(40,160,170),(170,60,90),(120,120,120),(230,130,180),(90,60,30),(100,180,230),(180,200,60)]
def cells_of(bricks, swap):
    occ={}; ov=0
    for i,b in enumerate(bricks):
        a,c=(b['w'],b['h']) if swap else (b['h'],b['w'])
        for dx in range(a):
            for dy in range(c):
                k=(b['x']+dx,b['y']+dy,b['z'])
                if k in occ: ov+=1
                occ[k]=i
    return occ, ov
def stud_components(bricks, occ):
    n=len(bricks); par=list(range(n))
    def f(i):
        while par[i]!=i: par[i]=par[par[i]]; i=par[i]
        return i
    for (x,y,z),i in occ.items():
        j=occ.get((x,y,z+1))
        if j is not None and j!=i: par[f(i)]=f(j)
    return [f(i) for i in range(n)]
def draw(bricks, swap, mode, fn, size=360):
    occ,ov=cells_of(bricks,swap)
    comp=stud_components(bricks,occ)
    roots=sorted(set(comp), key=lambda r:-sum(1 for c in comp if c==r))
    rid={r:k for k,r in enumerate(roots)}
    cells={}
    for k,i in occ.items():
        if mode=='comp': base=PAL[rid[comp[i]]%len(PAL)]
        else: base=(242,190,40)
        j=(i*37)%11-5
        cells[k]=tuple(max(0,min(255,c+j*3)) for c in base)
    im=render(cells, owner=occ, size=size, studs=False)
    im.save(fn); return dict(bricks=len(bricks), voxels=len(occ), overlap=ov, stud_components=len(roots))
def parse_txt(p):
    bs=[]
    for line in open(p):
        m=re.match(r'\s*(\d+)x(\d+)\s*\((\d+),(\d+),(\d+)\)',line)
        if m: h,w,x,y,z=map(int,m.groups()); bs.append(dict(h=h,w=w,x=x,y=y,z=z))
    return bs
groups=[('camera_L2_P1_G','A','camera_L2_P01'),('car_L5_P1_G','A','car_L5_P01'),('guitar_L1_P2_G','B','guitar_L1_P01'),('vessel_L1_P2_G','B','vessel_L1_P01')]
info={}
for g,part,pid in groups:
    d=find_dir(g)
    raw=json.load(open(d+'/raw_geometry.json'))['bricks']; fin=json.load(open(d+'/model.json'))['bricks']
    sp=json.load(open(d+'/source_prompt.json'))
    # choose orientation convention that reproduces occupied voxels without overlap
    v=json.load(open(d+'/validation.json'))
    best=None
    for swap in (False,True):
        occ,ov=cells_of(fin,swap)
        if ov==0 and len(occ)==v['occupied_voxels']: best=swap
    sw=bool(best)
    r1=draw(raw,sw,'comp',f'{OUT}/{g}_raw.png'); r2=draw(fin,sw,'comp',f'{OUT}/{g}_fin.png')
    bt=parse_txt(find_file(part,pid)); r3=draw(bt,False,'comp',f'{OUT}/{g}_bgpt.png')
    rep=json.load(open(os.path.dirname(find_file(part,pid))+'/report.json'))
    info[g]=dict(prompt=sp, swap=sw, raw=r1, final=r2, brickgpt=r3, brickgpt_report={k:rep.get(k) for k in ('brick_count','stable','regen_count','caption')})
    print(g, sw, r1, r2, r3, rep.get('stable'))
json.dump(info, open(OUT+'/qual_info.json','w'), ensure_ascii=False, indent=1, default=str)
