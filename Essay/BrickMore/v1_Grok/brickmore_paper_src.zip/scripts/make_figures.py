import json, glob, os, re, sys, csv, statistics as st, collections
sys.path.insert(0, os.path.dirname(__file__))
from isorender import render, voxels_yup_to_cells, bricks_to_cells
from PIL import Image
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager
font_manager.fontManager.addfont('/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc')
plt.rcParams['font.family'] = ['Noto Sans CJK JP', 'DejaVu Sans']
plt.rcParams['axes.unicode_minus'] = False
plt.rcParams['font.size'] = 9

SRC = '/workspace/brickmore/src/'
T = SRC + 'Train/'
OUT = '/workspace/brickmore/paper/figures/'
os.makedirs(OUT + 'renders', exist_ok=True)
DATA = {}

CATS = ['basket','bed','bench','birdhouse','bookshelf','bottle','bowl','bus','camera','car','chair',
        'guitar','jar','mug','piano','pot','sofa','table','tower','train','vessel']

# ---------- 1. gallery of 21 categories (AI_A sample m0001 & AI_B sample m0001) ----------
def gallery():
    for shard, base in (('A', T + 'samples/models/'), ('B', T + 'datasets/AI_B/samples/models/')):
        for c in CATS:
            f = glob.glob(base + c + '/*/model.json')[0]
            m = json.load(open(f))
            im = render(voxels_yup_to_cells(m['voxels']), size=300, edge=(120, 120, 120))
            im.save(OUT + f'renders/vox_{shard}_{c}.png')
            DATA.setdefault('gallery', {})[f'{shard}_{c}'] = dict(modelId=m['modelId'], voxels=m['actualVoxelCount'])
    # compose 3 rows x 7 cols per shard B (main) + A
    for shard in ('A', 'B'):
        W, H = 300, 300
        canvas = Image.new('RGB', (7 * W, 3 * (H + 34)), 'white')
        from PIL import ImageDraw, ImageFont
        font = ImageFont.truetype('/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc', 26)
        d = ImageDraw.Draw(canvas)
        for i, c in enumerate(CATS):
            r, k = divmod(i, 7)
            im = Image.open(OUT + f'renders/vox_{shard}_{c}.png')
            canvas.paste(im, (k * W, r * (H + 34)), im)
            tw = d.textlength(c, font=font)
            d.text((k * W + (W - tw) / 2, r * (H + 34) + H + 0), c, fill=(30, 30, 30), font=font)
        canvas.save(OUT + f'fig_gallery_{shard}.png')

# ---------- 2. assembly examples from Train/preview/piano_table_retile ----------
def assembly_examples():
    rows = []
    for d in sorted(glob.glob(T + 'preview/piano_table_retile/results/*/*/*')):
        mid = d.split('/')[-1]
        s = json.load(open(d + '/source.model.json')); t = json.load(open(d + '/target.model.json'))
        a = json.load(open(d + '/assembly.json')); p = json.load(open(d + '/physics.json')); v = json.load(open(d + '/validation.json'))
        S = {(q['x'], q['z'], q['y']) for q in s['voxels']}
        Tt = voxels_yup_to_cells(t['voxels'])
        added = set(Tt) - S
        render(voxels_yup_to_cells(s['voxels']), size=320, edge=(120, 120, 120)).save(OUT + f'renders/src_{mid}.png')
        render(Tt, size=320, edge=(120, 120, 120), highlight=added).save(OUT + f'renders/tgt_{mid}.png')
        c, o = bricks_to_cells(a['bricks'])
        render(c, o, size=320, studs=True).save(OUT + f'renders/brk_{mid}.png')
        rows.append(dict(model=mid, status=a['status'], valid=v.get('passed'), bricks=len(a['bricks']),
                         sourceVoxels=len(S), targetVoxels=len(Tt), added=len(added), removed=len(S - set(Tt)),
                         physics=p.get('status'), clutchN=p.get('minimumRequiredClutchNewtonsPerStud'),
                         tippingDeg=p.get('gravityOnlyTippingAngleDegrees'), prefix=p.get('layerPrefixGravityPassed'),
                         studComponents=v.get('studComponentCount'), groundedComponents=v.get('groundedComponentCount')))
    DATA['assembly_examples'] = rows

# ---------- 3. pipeline evolution ----------
def pipeline_chart():
    stages = ['严格策略 v3\n(10-11)', '放宽档\n多接地组件\n(10-12)', '接口重铺\nretile 全量\n(10-13)', '钢琴B重生成\n后预览统计\n(10-14)']
    geo = [7902, 65503, 79298, 79301]
    eq = [None, 2650, 220, None]
    pre = [None, 478, 128, None]
    fig, ax = plt.subplots(1, 2, figsize=(7.0, 2.6), gridspec_kw=dict(width_ratios=[1.25, 1]))
    b = ax[0].bar(range(4), [g / 800 for g in geo], color=['#9bb7d4', '#5b8fc7', '#2c5d9e', '#173a6a'])
    for i, g in enumerate(geo):
        ax[0].text(i, g / 800 + 1.5, f'{g:,}\n({g/800:.2f}%)', ha='center', va='bottom', fontsize=7)
    ax[0].set_xticks(range(4)); ax[0].set_xticklabels(stages, fontsize=6.5)
    ax[0].set_ylim(0, 125); ax[0].set_ylabel('几何装配通过率 (%)'); ax[0].set_title('(a) 80,000 模型几何装配通过数', fontsize=8.5)
    lab = ['放宽档 (10-12)', 'retile 全量 (10-13)']
    x = [0, 1]; w = 0.36
    ax[1].bar([i - w/2 for i in x], [2650, 220], w, label='最终状态自重平衡通过', color='#e3a33b')
    ax[1].bar([i + w/2 for i in x], [478, 128], w, label='最终+全部完成层前缀通过', color='#b5482f')
    for i, (e, p) in enumerate(zip([2650, 220], [478, 128])):
        ax[1].text(i - w/2, e * 1.15, f'{e:,}', ha='center', fontsize=7); ax[1].text(i + w/2, p * 1.15, f'{p:,}', ha='center', fontsize=7)
    ax[1].set_yscale('log'); ax[1].set_ylim(50, 20000); ax[1].set_xticks(x); ax[1].set_xticklabels(lab, fontsize=7)
    ax[1].set_title('(b) 假设条件下自重静力筛查通过数（对数轴）', fontsize=8.5); ax[1].legend(fontsize=6.5, loc='upper right', frameon=False)
    for a_ in ax: a_.spines[['top', 'right']].set_visible(False)
    plt.tight_layout(); plt.savefig(OUT + 'fig_pipeline_evolution.pdf'); plt.close()

# ---------- 4. per-category pass rates ----------
def category_chart():
    strict = json.load(open(T + 'datasets/assembly_80000/assembly_summary.json'))
    sc = collections.Counter(); tot = collections.Counter()
    for sh in ('A', 'B'):
        for c, cnt in strict['shards'][sh]['categoryStatusCounts'].items():
            sc[c] += cnt.get('success', 0); tot[c] += sum(cnt.values())
    rel = collections.Counter(); ret = collections.Counter(); n = collections.Counter(); eq = collections.Counter()
    for r in csv.DictReader(open(T + 'datasets/retile_assembly_80000/category_summary.csv', encoding='utf-8-sig')):
        c = r['group'][2:]
        rel[c] += int(r['baselinePassed']); ret[c] += int(r['geometryPassed']); n[c] += int(r['modelCount']); eq[c] += int(r['finalGravityEquilibriumPassed'])
    assert sum(n.values()) == 80000 and sum(ret.values()) == 79298 and sum(rel.values()) == 65503 and sum(sc.values()) == 7902
    DATA['category'] = {c: dict(n=n[c], strict=sc[c], relaxed=rel[c], retile=ret[c], finalEq=eq[c]) for c in CATS}
    fig, ax = plt.subplots(figsize=(7.0, 2.5))
    x = range(len(CATS)); w = 0.27
    ax.bar([i - w for i in x], [100 * sc[c] / tot[c] for c in CATS], w, label='严格策略 v3（原发布）', color='#c9d6e8')
    ax.bar([i for i in x], [100 * rel[c] / n[c] for c in CATS], w, label='放宽档（多接地组件）', color='#6f9bd1')
    ax.bar([i + w for i in x], [100 * ret[c] / n[c] for c in CATS], w, label='接口重铺 retile', color='#1f4e8c')
    ax.set_xticks(list(x)); ax.set_xticklabels(CATS, rotation=55, ha='right', fontsize=7)
    ax.set_ylabel('几何装配通过率 (%)'); ax.set_ylim(0, 105)
    ax.legend(fontsize=7, ncol=3, loc='lower center', bbox_to_anchor=(0.5, 1.0), frameon=False)
    ax.spines[['top', 'right']].set_visible(False)
    plt.tight_layout(); plt.savefig(OUT + 'fig_category_rates.pdf'); plt.close()

# ---------- 5. physics status distribution ----------
def physics_chart():
    ret = json.load(open(T + 'datasets/retile_assembly_80000/summary.json'))['physicsStatusCounts']
    rel = json.load(open(T + 'datasets/relaxed_assembly_80000/assembly_summary.json'))['physicalStatusCounts']
    DATA['physics_status'] = dict(retile=ret, relaxed=rel)
    keys = ['gravity_equilibrium_passed', 'requires_uncalibrated_clutch', 'clutch_requirement_inconclusive',
            'global_tipping_or_zero_margin', 'physics_solver_inconclusive', 'solver_witness_rejected', 'not_evaluated_geometry_failed']
    names = ['仅受压自重平衡通过', '需未标定咬合拉力', '咬合需求未确定(超时)', '整体倾覆/零裕度', '求解器未定论', '见证被拒绝', '几何失败未评估']
    colors = ['#3a8f4b', '#e3a33b', '#f2d27a', '#b5482f', '#888888', '#444444', '#c9c9c9']
    fig, ax = plt.subplots(figsize=(7.0, 1.7))
    for row, (lab, dd) in enumerate((('放宽档 (65,503 几何通过)', rel), ('retile 全量 (79,298 几何通过)', ret))):
        left = 0
        for k, nm, col in zip(keys, names, colors):
            v = dd.get(k, 0)
            ax.barh(row, v, left=left, color=col, label=nm if row == 0 else None, edgecolor='white', linewidth=0.3)
            if v > 2500: ax.text(left + v / 2, row, f'{v:,}', ha='center', va='center', fontsize=6.5)
            left += v
    ax.set_yticks([0, 1]); ax.set_yticklabels(['放宽档', 'retile 全量'], fontsize=8)
    ax.set_xlim(0, 80000); ax.set_xlabel('模型数（共 80,000）', fontsize=8)
    ax.legend(fontsize=6.3, ncol=4, loc='lower center', bbox_to_anchor=(0.5, 1.0), frameon=False)
    ax.spines[['top', 'right']].set_visible(False)
    plt.tight_layout(); plt.savefig(OUT + 'fig_physics_status.pdf'); plt.close()

# ---------- 6. comparison: BrickGPT vs BrickNet on 114 prompts ----------
def comparison():
    gpt = {}
    for f in glob.glob(SRC + 'BrickNet_BrickGPT_Compirasion/BrickGPT?*/ab_experiment_20261109/*/*/report.json'):
        r = json.load(open(f)); gpt[(r['part'], r['prompt_id'])] = r
    md = glob.glob(SRC + 'BrickNet_BrickGPT_Compirasion/BrickGPT/*.md')[0]
    net = {}; part = None
    for line in open(md, encoding='utf-8'):
        if line.startswith('### A'): part = 'A'
        if line.startswith('### B'): part = 'B'
        m = re.match(r'\|\s*\d+\s*\|\s*(\S+)\s*\|\s*(\S+)\s*\|\s*L(\d)\s*\|\s*(\d+)\s*\|\s*(\d+)\s*\|\s*(\d+)\s*\|', line)
        if m and part:
            net[(part, m.group(1))] = dict(category=m.group(2), level=int(m.group(3)), attempt=int(m.group(4)), n_parts=int(m.group(5)), ldr=int(m.group(6)))
    assert len(gpt) == 114 and len(net) == 114, (len(gpt), len(net))
    common = sorted(set(gpt) & set(net)); assert len(common) == 114
    res = {}
    for L in range(1, 6):
        ks = [k for k in common if gpt[k]['level'] == L]
        res[L] = dict(n=len(ks), gpt_stable=sum(gpt[k]['stable'] for k in ks),
                      gpt_med=st.median([gpt[k]['brick_count'] for k in ks]), net_med=st.median([net[k]['n_parts'] for k in ks]),
                      net_first=sum(net[k]['attempt'] == 1 for k in ks), gpt_noregen=sum(gpt[k]['n_regenerations'] == 0 for k in ks))
    allg = [gpt[k]['brick_count'] for k in common]; alln = [net[k]['n_parts'] for k in common]
    DATA['comparison'] = dict(by_level=res, gpt_total_stable=sum(gpt[k]['stable'] for k in common),
                              gpt_median=st.median(allg), net_median=st.median(alln), gpt_mean_sec=st.mean(gpt[k]['seconds'] for k in common),
                              gpt_regen_hist=dict(collections.Counter(gpt[k]['n_regenerations'] for k in common)),
                              gpt_reject=dict(sum((collections.Counter(gpt[k]['rejection_reasons']) for k in common), collections.Counter())),
                              net_attempt_hist=dict(collections.Counter(net[k]['attempt'] for k in common)),
                              gpt_stable_mean_bricks=st.mean([gpt[k]['brick_count'] for k in common if gpt[k]['stable']]),
                              gpt_unstable_mean_bricks=st.mean([gpt[k]['brick_count'] for k in common if not gpt[k]['stable']]))
    # BrickMore human judgement per level (best_all.md : 26 all-fail groups)
    fail = {1: 3, 2: 5, 3: 4, 4: 6, 5: 8}
    fig, ax = plt.subplots(1, 3, figsize=(7.0, 2.3))
    Ls = [1, 2, 3, 4, 5]; w = 0.38
    ax[0].bar([l - w/2 for l in Ls], [100 * res[l]['gpt_stable'] / res[l]['n'] for l in Ls], w, color='#b5482f', label='BrickGPT：stable=true')
    ax[0].bar([l + w/2 for l in Ls], [100 * (21 - fail[l]) / 21 for l in Ls], w, color='#1f4e8c', label='BrickMore-48：人工判定有合格模型的组')
    ax[0].set_xticks(Ls); ax[0].set_xticklabels([f'L{l}' for l in Ls]); ax[0].set_ylim(0, 100); ax[0].set_ylabel('%')
    ax[0].set_title('(a) 分级通过比例（判据不同）', fontsize=8); ax[0].legend(fontsize=5.2, loc='upper center', bbox_to_anchor=(0.5, -0.13), frameon=False, ncol=1)
    ax[1].bar([l - w/2 for l in Ls], [res[l]['gpt_med'] for l in Ls], w, color='#b5482f', label='BrickGPT 砖块数')
    ax[1].bar([l + w/2 for l in Ls], [res[l]['net_med'] for l in Ls], w, color='#e3a33b', label='BrickNet 1.7B 零件数')
    ax[1].set_xticks(Ls); ax[1].set_xticklabels([f'L{l}' for l in Ls]); ax[1].set_title('(b) 同一 114 条提示词的中位规模', fontsize=8)
    ax[1].legend(fontsize=6, frameon=False)
    ax[2].scatter(alln, allg, s=8, c=['#1f4e8c' if gpt[k]['stable'] else '#b5482f' for k in common], alpha=.8)
    ax[2].set_xlabel('BrickNet 零件数', fontsize=7.5); ax[2].set_ylabel('BrickGPT 砖块数', fontsize=7.5)
    ax[2].set_title('(c) 逐提示词配对（蓝=stable）', fontsize=8)
    for a_ in ax: a_.spines[['top', 'right']].set_visible(False); a_.tick_params(labelsize=7)
    plt.tight_layout(); plt.savefig(OUT + 'fig_comparison.pdf'); plt.close()
    # failure/rejection breakdown
    fig, ax = plt.subplots(1, 2, figsize=(7.0, 2.0))
    rj = DATA['comparison']['gpt_reject']
    kk = ['already_rejected', 'collision', 'not_in_library', 'out_of_bounds']
    ax[0].barh(kk[::-1], [rj.get(k, 0) for k in kk[::-1]], color='#b5482f')
    for i, k in enumerate(kk[::-1]): ax[0].text(rj.get(k, 0) + 80, i, f'{rj.get(k,0):,}', va='center', fontsize=6.5)
    ax[0].set_title('(a) BrickGPT 逐砖拒绝采样原因（114 条累计）', fontsize=8); ax[0].set_xlim(0, 10000)
    nf = {'路径不完整\n(dangling node)': 24, '零件缺连接器': 10, '边语法不合法': 10, '索引/量纲错误': 6, '词表外零件/颜色': 3}
    ax[1].barh(list(nf)[::-1], list(nf.values())[::-1], color='#e3a33b')
    for i, v in enumerate(list(nf.values())[::-1]): ax[1].text(v + .4, i, str(v), va='center', fontsize=6.5)
    ax[1].set_title('(b) BrickNet 1.7B 失败尝试类型（共 53 次）', fontsize=8); ax[1].set_xlim(0, 30)
    for a_ in ax: a_.spines[['top', 'right']].set_visible(False); a_.tick_params(labelsize=6.5)
    plt.tight_layout(); plt.savefig(OUT + 'fig_failures.pdf'); plt.close()

# ---------- 7. Q-series fixed-sample benchmark ----------
def qseries_chart():
    st_ = ['原发布规则', 'Q3：仅新增≤2%', 'Q4 第一轮', 'Q4 稀疏约束']
    a = [13, 23, 23, 24]; b = [9, 32, 33, 33]
    fig, ax = plt.subplots(figsize=(3.3, 2.1))
    ax.bar(range(4), a, color='#6f9bd1', label='A / 80'); ax.bar(range(4), b, bottom=a, color='#1f4e8c', label='B / 80')
    for i in range(4): ax.text(i, a[i] + b[i] + 1, f'{a[i]+b[i]}\n({(a[i]+b[i])/1.6:.2f}%)', ha='center', fontsize=6.5)
    ax.set_xticks(range(4)); ax.set_xticklabels(st_, fontsize=6.5, rotation=15); ax.set_ylim(0, 80)
    ax.set_ylabel('几何通过数 / 160', fontsize=7.5); ax.legend(fontsize=6.5, frameon=False, loc='upper left')
    ax.spines[['top', 'right']].set_visible(False); ax.tick_params(labelsize=7)
    plt.tight_layout(); plt.savefig(OUT + 'fig_qseries.pdf'); plt.close()

if __name__ == '__main__':
    gallery(); assembly_examples(); pipeline_chart(); category_chart(); physics_chart(); comparison(); qseries_chart()
    json.dump(DATA, open(OUT + 'figure_data.json', 'w'), ensure_ascii=False, indent=1, default=str)
    print(json.dumps({k: v for k, v in DATA.items() if k in ('comparison', 'assembly_examples')}, ensure_ascii=False, indent=0, default=str)[:6000])
