"""Simple isometric renderer for voxel models / brick layouts (internal Z-up).
Draws only exposed faces of unit cells in painter order; brick boundaries get dark edges.
Vertical cell height = 1.2 stud (LDraw 24/20)."""
import math
from PIL import Image, ImageDraw

C30 = math.cos(math.radians(30)); S30 = 0.5

def _shade(rgb, f):
    return tuple(max(0, min(255, int(c * f))) for c in rgb)

def render(cells, owner=None, size=420, hz=1.2, edge=(40, 40, 40), studs=False, bg=(255, 255, 255, 0), outline_all=False, highlight=None):
    """cells: dict {(x,y,z): (r,g,b)} with z up. owner: optional {(x,y,z): brick_id}."""
    if not cells:
        return Image.new('RGBA', (size, size), bg)
    def proj(x, y, z):
        return ((x - y) * C30, (x + y) * S30 - z * hz)
    xs = [p[0] for p in cells]; ys = [p[1] for p in cells]; zs = [p[2] for p in cells]
    corners = [proj(x, y, z) for x in (min(xs), max(xs) + 1) for y in (min(ys), max(ys) + 1) for z in (min(zs), max(zs) + 1)]
    u0 = min(c[0] for c in corners); u1 = max(c[0] for c in corners)
    v0 = min(c[1] for c in corners); v1 = max(c[1] for c in corners)
    pad = 0.06
    scale = size * (1 - 2 * pad) / max(u1 - u0, v1 - v0)
    ou = size / 2 - (u0 + u1) / 2 * scale; ov = size / 2 - (v0 + v1) / 2 * scale
    def P(x, y, z):
        u, v = proj(x, y, z); return (ou + u * scale, ov + v * scale)
    ss = 3  # supersample
    big = Image.new('RGBA', (size * ss, size * ss), bg)
    d = ImageDraw.Draw(big)
    def PS(x, y, z):
        a, b = P(x, y, z); return (a * ss, b * ss)
    lw = max(1, int(ss * max(0.6, scale / 14)))
    order = sorted(cells, key=lambda p: (p[0] + p[1] + p[2], p[2]))
    def diff(p, q):
        if q not in cells: return True
        if owner is None: return outline_all
        return owner.get(p) != owner.get(q)
    for (x, y, z) in order:
        rgb = tuple(cells[(x, y, z)][:3])
        if highlight and (x, y, z) in highlight:
            rgb = (230, 40, 40)
        # top face (+z)
        if (x, y, z + 1) not in cells:
            poly = [PS(x, y, z + 1), PS(x + 1, y, z + 1), PS(x + 1, y + 1, z + 1), PS(x, y + 1, z + 1)]
            d.polygon(poly, fill=_shade(rgb, 1.08))
            # edges: (x,y)->(x+1,y) neighbor y-1 ; etc.
            for (a, b, q) in (((x, y), (x + 1, y), (x, y - 1, z)), ((x + 1, y), (x + 1, y + 1), (x + 1, y, z)),
                              ((x + 1, y + 1), (x, y + 1), (x, y + 1, z)), ((x, y + 1), (x, y), (x - 1, y, z))):
                if diff((x, y, z), q) or (q in cells and (q[0], q[1], z + 1) in cells):
                    d.line([PS(a[0], a[1], z + 1), PS(b[0], b[1], z + 1)], fill=edge, width=lw)
            if studs:
                cu, cv = PS(x + .5, y + .5, z + 1)
                r = 0.3 * scale * ss
                d.ellipse([cu - r * C30 * 1.15, cv - r * 0.62, cu + r * C30 * 1.15, cv + r * 0.62], outline=_shade(rgb, .7), width=max(1, lw // 2))
        # +x face
        if (x + 1, y, z) not in cells:
            poly = [PS(x + 1, y, z), PS(x + 1, y + 1, z), PS(x + 1, y + 1, z + 1), PS(x + 1, y, z + 1)]
            d.polygon(poly, fill=_shade(rgb, 0.80))
            for (a, b, q) in (((y, z), (y + 1, z), (x, y, z - 1)), ((y + 1, z), (y + 1, z + 1), (x, y + 1, z)),
                              ((y + 1, z + 1), (y, z + 1), (x, y, z + 1)), ((y, z + 1), (y, z), (x, y - 1, z))):
                if diff((x, y, z), q) or (q in cells and (x + 1, q[1], q[2]) in cells):
                    d.line([PS(x + 1, a[0], a[1]), PS(x + 1, b[0], b[1])], fill=edge, width=lw)
        # +y face
        if (x, y + 1, z) not in cells:
            poly = [PS(x, y + 1, z), PS(x + 1, y + 1, z), PS(x + 1, y + 1, z + 1), PS(x, y + 1, z + 1)]
            d.polygon(poly, fill=_shade(rgb, 0.62))
            for (a, b, q) in (((x, z), (x + 1, z), (x, y, z - 1)), ((x + 1, z), (x + 1, z + 1), (x + 1, y, z)),
                              ((x + 1, z + 1), (x, z + 1), (x, y, z + 1)), ((x, z + 1), (x, z), (x - 1, y, z))):
                if diff((x, y, z), q) or (q in cells and (q[0], y + 1, q[2]) in cells):
                    d.line([PS(a[0], y + 1, a[1]), PS(b[0], y + 1, b[1])], fill=edge, width=lw)
    return big.resize((size, size), Image.LANCZOS)

def voxels_yup_to_cells(voxels):
    return {(v['x'], v['z'], v['y']): tuple(v['color']) for v in voxels}

def bricks_to_cells(bricks, jitter=True):
    import random
    cells = {}; owner = {}
    rnd = random.Random(7)
    for i, b in enumerate(bricks):
        c = b['color']
        rgb = ((c >> 16) & 255, (c >> 8) & 255, c & 255) if isinstance(c, int) else tuple(c)
        f = rnd.uniform(0.86, 1.12) if jitter else 1.0
        rgb = tuple(max(0, min(255, int(v * f + (8 if v < 30 else 0)))) for v in rgb)
        for x in range(b['x'], b['x'] + b['h']):
            for y in range(b['y'], b['y'] + b['w']):
                cells[(x, y, b['z'])] = rgb; owner[(x, y, b['z'])] = i
    return cells, owner
